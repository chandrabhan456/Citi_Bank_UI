import React from 'react'

function Configuration() {
  return (
    <div className=' min-h-screen bg-[#1D2041]'>
    <div className='p-4 text-white'>Configuration</div>
    </div>
  )
}

export default Configuration
