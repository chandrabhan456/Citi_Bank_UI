import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';

// Register necessary components and plugins
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, ChartDataLabels);

const Graph2 = () => {
  // Define data for the chart
  const chartData = {
    labels: [
      'Cashback Master', 'E-Shopper', 'International Gold', 'Family Planner',
      'Frequent Flyer', 'Fuel Saver', 'Student Achieve', 'Travel Elite', 'Weekend Boost'
    ],
    datasets: [
      {
        label: 'Revenue ($)',
        data: [150, 100, 200, 350, 400, 50, 75, 250, 500],
        backgroundColor: 'rgba(34, 139, 34, 0.8)',  // Green color with slight transparency
        borderColor: 'rgba(34, 139, 34, 1)',        // Solid green border
        borderWidth: 1,
      },
    ],
  };

  // Chart options
 const options = {
  plugins: {
    legend: {
      display: false, // Hide the legend
    },
    datalabels: {
      align: 'end',
      anchor: 'end',
      formatter: Math.round,
      color: 'black', // Set data label text color to black
    },
    title: {
      display: true, // Enable the title
      text: 'Revenue Generated for Credit Card Campaign', // Set the title text
      color: 'black', // Set the title color
      font: {
        size: 16, // Set the title font size
        weight: 'bold', // Make the title bold
      },
    },
  },
  scales: {
    x: {
      title: {
        display: true,
        text: 'Credit Card Campaign',
        color: 'grey', // Set x-axis title color to grey
        font: {
          size: 14, // Make the title slightly larger
          weight: 'bold', // Make the title bold
        },
      },
      ticks: {
        color: 'black', // Set x-axis ticks color to black
        font: {
          size: 12, // Set tick label size
        },
      },
    },
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Revenue($)',
        color: 'grey', // Set y-axis title color to grey
        font: {
          size: 14, // Make the title slightly larger
          weight: 'bold', // Make the title bold
        },
      },
      ticks: {
        color: 'black', // Set y-axis ticks color to black
        font: {
          size: 12, // Set tick label size
        },
      },
    },
  },
  maintainAspectRatio: false, // Allow the chart to fill the container
};


  return (
    <div style={{ height: '400px', maxWidth: '800px', margin: '0 auto' }}>
      <Bar data={chartData} options={options} />
    </div>
  );
};

export default Graph2;
